package ru.hexatime.events.mystic;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.Location;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitTask;
import ru.hexatime.events.EventsPlugin;
import ru.hexatime.events.core.EventModule;
import ru.hexatime.events.core.Messages;
import ru.hexatime.events.mystic.logic.ClaimCooldown;
import ru.hexatime.events.mystic.logic.LootBook;
import ru.hexatime.events.mystic.logic.LootLayout;
import ru.hexatime.events.mystic.logic.SpawnMath;
import ru.hexatime.events.mystic.logic.TimeFormat;
import ru.hexatime.events.mystic.logic.WeightedPicker;
import ru.hexatime.events.mystic.logic.ZoneBox;

import java.util.ArrayList;
import java.util.Collection;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.OptionalInt;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ThreadLocalRandom;
import java.util.logging.Level;

/**
 * Модуль Mystic. Жизненный цикл одного Mystic:
 * сундук ставится и защищается → таймер до открытия (над сундуком) → OPEN: игроки забирают награды из общего GUI →
 * когда забрано всё — ещё despawn-after-loot-seconds секунд → исчезает → через interval-minutes следующий.
 * Единственная фоновая задача — tickTask (раз в секунду).
 */
public final class MysticModule implements EventModule {

    public static final String ID = "mystic";
    static final int GUI_SIZE = 54;

    private final EventsPlugin plugin;
    private final RewardStore store;
    private final MysticStateFile stateFile;
    private final MysticCommands commands = new MysticCommands(this);
    private final List<MysticSession> sessions = new ArrayList<>();
    private final ClaimCooldown cooldown = new ClaimCooldown();
    private final Map<Rarity, UUID> editors = new EnumMap<>(Rarity.class);
    private final NamespacedKey itemKey;

    private MysticConfig cfg;
    private BukkitTask tickTask;
    private MysticListener listener;
    private ProtectionListener protection;
    private boolean running;
    private boolean autoSpawn = true;
    private boolean spawning;
    private boolean immediateNext;
    private long retryAtMs;

    public MysticModule(EventsPlugin plugin) {
        this.plugin = plugin;
        this.store = new RewardStore(plugin);
        this.stateFile = new MysticStateFile(plugin);
        this.itemKey = new NamespacedKey(plugin, "mystic_rarity");
        this.cfg = MysticConfig.load(plugin.getConfig());
    }

    EventsPlugin plugin() {
        return plugin;
    }

    RewardStore store() {
        return store;
    }

    private static long ms() {
        return System.currentTimeMillis();
    }

    // ───────────────────────── EventModule ─────────────────────────

    @Override
    public String id() {
        return ID;
    }

    @Override
    public Component displayName() {
        return Component.text("Mystic", NamedTextColor.WHITE);
    }

    @Override
    public Material iconMaterial() {
        return Material.ENDER_CHEST;
    }

    @Override
    public boolean isEnabled() {
        return running;
    }

    @Override
    public void enable() {
        cfg = MysticConfig.load(plugin.getConfig());
        if (cfg.enabled) {
            start();
        }
    }

    @Override
    public void disable() {
        stop(false);
    }

    @Override
    public void reload() {
        cfg = MysticConfig.load(plugin.getConfig());
        if (running && !cfg.enabled) {
            stop(true);
        } else if (!running && cfg.enabled) {
            start();
        } else if (running) {
            store.loadAll();
            if (tickTask != null) {
                tickTask.cancel();
            }
            tickTask = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L, cfg.tickTicks);
        }
    }

    @Override
    public void openMenu(Player player) {
        player.openInventory(new MysticMenu(this).getInventory());
    }

    @Override
    public Component timeStatus() {
        long now = ms();
        long best = Long.MAX_VALUE;
        boolean open = false;
        long closesAt = Long.MAX_VALUE;
        for (MysticSession s : sessions) {
            if (s.state == MysticSession.State.WAITING) {
                best = Math.min(best, s.openAtMs);
            } else {
                open = true;
                closesAt = Math.min(closesAt, disappearAtMs(s));
            }
        }
        Messages m = plugin.messages();
        if (best != Long.MAX_VALUE) {
            return m.get("mystic-time-waiting", Messages.text("time", TimeFormat.words(best - now)));
        }
        if (open) {
            if (closesAt == Long.MAX_VALUE) {
                return m.get("mystic-time-open-forever");
            }
            return m.get("mystic-time-open", Messages.text("time", TimeFormat.words(closesAt - now)));
        }
        if (autoSpawn && retryAtMs > now) {
            return m.get("mystic-time-spawn", Messages.text("time", TimeFormat.words(retryAtMs - now)));
        }
        return m.get(autoSpawn ? "mystic-time-pending" : "mystic-time-paused");
    }

    @Override
    public Collection<String> subcommands() {
        return MysticCommands.SUBS;
    }

    @Override
    public boolean canUse(CommandSender sender, String sub) {
        return commands.canUse(sender, sub);
    }

    @Override
    public boolean handle(CommandSender sender, String sub, String[] args) {
        return commands.handle(sender, sub, args);
    }

    @Override
    public List<String> complete(CommandSender sender, String sub, String[] args) {
        return commands.complete(sender, sub, args);
    }

    // ───────────────────────── запуск / остановка ─────────────────────────

    private void start() {
        if (running) {
            return;
        }
        running = true;
        store.loadAll();
        listener = new MysticListener(this);
        protection = new ProtectionListener(this);
        Bukkit.getPluginManager().registerEvents(listener, plugin);
        Bukkit.getPluginManager().registerEvents(protection, plugin);
        // состояние восстанавливаем на следующем тике — к этому моменту миры точно загружены
        Bukkit.getScheduler().runTask(plugin, this::restoreState);
        tickTask = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L, cfg.tickTicks);
    }

    /** removeChests=false — остановка сервера (сундуки остаются в мире, состояние сохраняется); true — Mystic отключён в конфиге. */
    private void stop(boolean removeChests) {
        if (!running) {
            return;
        }
        running = false;
        if (tickTask != null) {
            tickTask.cancel();
            tickTask = null;
        }
        closeAdminMenus();
        if (removeChests) {
            for (MysticSession s : new ArrayList<>(sessions)) {
                despawn(s, false);
            }
            persist();
        } else {
            persist();   // снимок делается сразу, до очистки списка
            for (MysticSession s : new ArrayList<>(sessions)) {
                detach(s);
            }
            sessions.clear();
        }
        HandlerList.unregisterAll(listener);
        HandlerList.unregisterAll(protection);
        spawning = false;
    }

    private void closeAdminMenus() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.getOpenInventory().getTopInventory().getHolder(false) instanceof AdminRewardMenu) {
                p.closeInventory();   // onClose сохранит награды
            }
        }
    }

    private void restoreState() {
        if (!running) {
            return;
        }
        MysticStateFile.Loaded st = stateFile.load();
        autoSpawn = st.autoSpawn();
        retryAtMs = st.retryAtMs();
        if (retryAtMs == 0 && st.sessions().isEmpty()) {
            retryAtMs = ms() + cfg.intervalMs;   // первый запуск: первый Mystic через interval-minutes
        }
        for (MysticSession s : st.sessions()) {
            World w = Bukkit.getWorld(s.worldId);
            if (w == null) {
                plugin.getLogger().warning("Мир Mystic " + s.id + " не найден — запись пропущена");
                continue;
            }
            sessions.add(s);
            attach(s, w);
        }
    }

    private void persist() {
        stateFile.saveAsync(autoSpawn, retryAtMs, sessions);
    }

    // ───────────────────────── главный таймер ─────────────────────────

    private void tick() {
        long now = ms();
        for (MysticSession s : new ArrayList<>(sessions)) {
            try {
                tickSession(s, now);
            } catch (Throwable t) {
                plugin.getLogger().log(Level.SEVERE, "Ошибка в таймере Mystic " + s.id, t);
            }
        }
        if (autoSpawn && !spawning && now >= retryAtMs && sessions.stream().noneMatch(x -> !x.fromGive)) {
            spawnCycle(false);
        }
    }

    /**
     * Когда открытый Mystic исчезнет: через despawn-after-open-seconds после открытия, даже если награды остались;
     * если всё забрали раньше — через despawn-after-loot-seconds после этого (что наступит раньше).
     */
    private long disappearAtMs(MysticSession s) {
        long at = cfg.despawnAfterOpenMs > 0 ? s.openedAtMs + cfg.despawnAfterOpenMs : Long.MAX_VALUE;
        if (s.completedAtMs > 0) {
            at = Math.min(at, s.completedAtMs + cfg.despawnAfterLootMs);
        }
        return at;
    }

    private void tickSession(MysticSession s, long now) {
        World w = Bukkit.getWorld(s.worldId);
        if (w == null) {
            return;
        }
        if (s.state == MysticSession.State.WAITING && now >= s.openAtMs) {
            openSession(s);
            if (!sessions.contains(s)) {
                return;
            }
        }
        if (s.state == MysticSession.State.OPEN) {
            if (now >= disappearAtMs(s)) {
                if (!s.fromGive) {
                    retryAtMs = ms() + cfg.intervalMs;   // следующий Mystic появится через interval-minutes после исчезновения
                }
                despawn(s, true);
                return;
            }
        }
        Block b = w.getBlockAt(s.x, s.y, s.z);
        if (b.getType() != Material.ENDER_CHEST) {
            b.setType(Material.ENDER_CHEST, false);   // сундук Mystic нельзя «потерять»
        }
        updateHologram(s, now);
    }

    // ───────────────────────── появление ─────────────────────────

    private World resolveWorld() {
        World w = Bukkit.getWorld(cfg.worldName);
        return w != null && w.getEnvironment() == World.Environment.NORMAL ? w : null;
    }

    private Rarity pickRarity() {
        Map<Rarity, Integer> eff = new EnumMap<>(Rarity.class);
        for (Rarity r : Rarity.values()) {
            eff.put(r, store.count(r) > 0 ? cfg.weights.getOrDefault(r, 0) : 0);
        }
        return WeightedPicker.pick(eff, ThreadLocalRandom.current());
    }

    private void spawnCycle(boolean immediate) {
        if (immediate) {
            immediateNext = true;
        }
        if (spawning) {
            return;
        }
        World w = resolveWorld();
        if (w == null) {
            plugin.getLogger().warning("Mystic: мир '" + cfg.worldName + "' не найден или это не Overworld");
            retryAtMs = ms() + cfg.retryDelayMs;
            return;
        }
        Rarity r = pickRarity();
        if (r == null) {
            plugin.getLogger().warning("Mystic: во всех хранилищах нет наград (или нулевые веса) — событие не запущено. /event rewards <редкость>");
            retryAtMs = ms() + cfg.retryDelayMs;
            return;
        }
        spawning = true;
        attempt(w, r, 0);
    }

    /** Одна попытка: случайные X/Z → загрузка чанков зоны → проверки. Число попыток ограничено spawn-attempts. */
    private void attempt(World w, Rarity r, int n) {
        if (!running || !autoSpawn && !immediateNext) {
            spawning = false;
            return;
        }
        if (n >= cfg.attempts) {
            plugin.getLogger().warning("Mystic: за " + cfg.attempts + " попыток не найдено подходящее место, повтор через "
                    + cfg.retryDelayMs / 1000 + " с");
            retryAtMs = ms() + cfg.retryDelayMs;
            spawning = false;
            immediateNext = false;
            return;
        }
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        int x = SpawnMath.between(rnd, cfg.minX, cfg.maxX);
        int z = SpawnMath.between(rnd, cfg.minZ, cfg.maxZ);
        int rad = cfg.radius;
        List<CompletableFuture<Chunk>> loads = new ArrayList<>();
        for (int cx = (x - rad) >> 4; cx <= (x + rad) >> 4; cx++) {
            for (int cz = (z - rad) >> 4; cz <= (z + rad) >> 4; cz++) {
                loads.add(w.getChunkAtAsync(cx, cz));
            }
        }
        CompletableFuture.allOf(loads.toArray(new CompletableFuture[0])).whenComplete((v, ex) -> {
            if (!plugin.isEnabled()) {
                return;
            }
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (!running) {
                    spawning = false;
                    return;
                }
                if (ex != null) {
                    attempt(w, r, n + 1);
                    return;
                }
                OptionalInt y = SpawnChecker.findPlacement(w, x, z, cfg, zonesIn(w));
                if (y.isEmpty()) {
                    attempt(w, r, n + 1);
                    return;
                }
                spawning = false;
                if (!autoSpawn && !immediateNext) {
                    return;
                }
                placeCycle(w, r, x, y.getAsInt(), z);
            });
        });
    }

    private List<ZoneBox> zonesIn(World w) {
        List<ZoneBox> out = new ArrayList<>();
        for (MysticSession s : sessions) {
            if (s.worldId.equals(w.getUID())) {
                out.add(s.zone);
            }
        }
        return out;
    }

    private void placeCycle(World w, Rarity r, int x, int y, int z) {
        boolean immediate = immediateNext;
        immediateNext = false;
        long now = ms();
        MysticSession s = new MysticSession(UUID.randomUUID(), r, w.getUID(), x, y, z, false, cfg.radius);
        s.openAtMs = immediate ? now : now + cfg.openDelayMs;
        sessions.add(s);
        attach(s, w);
        if (immediate) {
            openSession(s);
        }
        persist();
        announce(s);
    }

    /** Сообщение в общий чат: появился Mystic, его редкость и координаты. */
    private void announce(MysticSession s) {
        Bukkit.broadcast(plugin.messages().get("mystic-announce",
                Messages.comp("rarity", s.rarity.component()),
                Messages.text("x", String.valueOf(s.x)),
                Messages.text("y", String.valueOf(s.y)),
                Messages.text("z", String.valueOf(s.z))));
    }

    /** Выданный командой /event give Mystic при установке: сразу открытый Mystic этой редкости. */
    boolean createGiven(Player p, Block placed, Rarity r) {
        World w = placed.getWorld();
        Messages m = plugin.messages();
        if (w.getEnvironment() != World.Environment.NORMAL) {
            m.send(p, "place-denied");
            return false;
        }
        if (store.count(r) == 0) {
            m.send(p, "pool-empty", Messages.comp("rarity", r.component()));
            return false;
        }
        ZoneBox zone = new ZoneBox(placed.getX(), placed.getZ(), cfg.radius);
        long minSq = (long) cfg.minDistance * cfg.minDistance;
        for (ZoneBox o : zonesIn(w)) {
            if (zone.intersects(o, 0) || zone.distanceSq(o) < minSq) {
                m.send(p, "place-denied");
                return false;
            }
        }
        MysticSession s = new MysticSession(UUID.randomUUID(), r, w.getUID(),
                placed.getX(), placed.getY(), placed.getZ(), true, cfg.radius);
        s.openAtMs = ms();
        sessions.add(s);
        attach(s, w);
        openSession(s);
        persist();
        return true;
    }

    // ───────────────────────── сессия: подключение, открытие, удаление ─────────────────────────

    private void attach(MysticSession s, World w) {
        w.getChunkAt(s.x >> 4, s.z >> 4).addPluginChunkTicket(plugin);   // чанк с сундуком не выгружается
        Block b = w.getBlockAt(s.x, s.y, s.z);
        if (b.getType() != Material.ENDER_CHEST) {
            b.setType(Material.ENDER_CHEST, false);
        }
        if (s.state == MysticSession.State.OPEN && s.book != null) {
            s.inventory = new MysticLootHolder(this, s).getInventory();
            if (s.lootStartedAtMs > 0) {
                scheduleReveals(s);
            }
        }
        spawnHolograms(s, w);
        updateHologram(s, ms());
    }

    /** WAITING → OPEN: выбираем награды из актуального (проверенного на дубликаты) хранилища и раскладываем. */
    private void openSession(MysticSession s) {
        List<ItemStack> pool = store.items(s.rarity);
        if (pool.isEmpty()) {
            plugin.getLogger().warning("Mystic " + s.rarity.id() + ": хранилище пусто — Mystic удалён");
            despawn(s, true);
            return;
        }
        s.book = new LootBook<>(LootLayout.generateCyclic(pool, GUI_SIZE, cfg.initialMin, cfg.initialMax,
                cfg.additional, cfg.delayPatternMs, ThreadLocalRandom.current()));
        s.state = MysticSession.State.OPEN;
        s.openedAtMs = ms();
        s.inventory = new MysticLootHolder(this, s).getInventory();
        persist();
        updateHologram(s, ms());
    }

    /** Первое открытие GUI: стартуют начальные 13–14 наград и последовательность дополнительных. */
    private void startLoot(MysticSession s) {
        s.lootStartedAtMs = ms();
        persist();
        scheduleReveals(s);
    }

    private void scheduleReveals(MysticSession s) {
        long now = ms();
        for (LootBook.View<ItemStack> v : s.book.snapshot()) {
            if (v.status() != LootBook.Status.HIDDEN) {
                continue;
            }
            long delay = s.lootStartedAtMs + v.revealOffsetMs() - now;
            int slot = v.slot();
            if (delay <= 0) {
                revealNow(s, slot);
            } else {
                long ticks = Math.max(1L, (delay + 49) / 50);
                s.revealTasks.add(Bukkit.getScheduler().runTaskLater(plugin, () -> revealNow(s, slot), ticks));
            }
        }
    }

    private void revealNow(MysticSession s, int slot) {
        if (!sessions.contains(s) || s.book == null || s.inventory == null) {
            return;
        }
        if (s.book.reveal(slot)) {
            ItemStack item = s.book.itemAt(slot);
            if (item != null) {
                s.inventory.setItem(slot, item.clone());
            }
        }
    }

    /** Снимает всё, что связано с сессией, но не трогает сам блок. */
    private void detach(MysticSession s) {
        s.revealTasks.forEach(BukkitTask::cancel);
        s.revealTasks.clear();
        if (s.inventory != null) {
            for (HumanEntity viewer : new ArrayList<>(s.inventory.getViewers())) {
                viewer.closeInventory();
            }
        }
        removeHolograms(s);
        World w = Bukkit.getWorld(s.worldId);
        if (w != null) {
            boolean shared = sessions.stream().anyMatch(o -> o != s && o.worldId.equals(s.worldId)
                    && (o.x >> 4) == (s.x >> 4) && (o.z >> 4) == (s.z >> 4));
            if (!shared) {
                w.getChunkAt(s.x >> 4, s.z >> 4).removePluginChunkTicket(plugin);
            }
        }
    }

    private void despawn(MysticSession s, boolean persistNow) {
        detach(s);
        World w = Bukkit.getWorld(s.worldId);
        if (w != null) {
            Block b = w.getBlockAt(s.x, s.y, s.z);
            if (b.getType() == Material.ENDER_CHEST) {
                b.setType(Material.AIR, false);
            }
        }
        sessions.remove(s);
        if (persistNow) {
            persist();
        }
    }

    // ───────────────────────── голограмма (надпись над сундуком) ─────────────────────────

    private void spawnHolograms(MysticSession s, World w) {
        removeHolograms(s);
        Location base = new Location(w, s.x + 0.5, s.y + cfg.holoHeight, s.z + 0.5);
        s.titleStand = spawnStand(base.clone().add(0, 0.6, 0),
                Component.text(cfg.holoTitle.replace("%rarity%", s.rarity.title()), s.rarity.color())
                        .decoration(TextDecoration.ITALIC, false));
        s.statusStand = spawnStand(base.clone().add(0, 0.3, 0), Component.text(""));
        s.timeStand = spawnStand(base, Component.text(""));
        s.lastStatusText = null;
        s.lastTimeText = null;
    }

    private ArmorStand spawnStand(Location loc, Component name) {
        return loc.getWorld().spawn(loc, ArmorStand.class, as -> {
            as.setInvisible(true);
            as.setGravity(false);
            as.setMarker(true);
            as.setSmall(true);
            as.setInvulnerable(true);
            as.setSilent(true);
            as.setPersistent(false);   // на диск не пишется — после рестарта создаётся заново
            as.setCustomNameVisible(true);
            as.customName(name);
        });
    }

    private void removeHolograms(MysticSession s) {
        if (s.titleStand != null && s.titleStand.isValid()) {
            s.titleStand.remove();
        }
        if (s.statusStand != null && s.statusStand.isValid()) {
            s.statusStand.remove();
        }
        if (s.timeStand != null && s.timeStand.isValid()) {
            s.timeStand.remove();
        }
        s.titleStand = null;
        s.statusStand = null;
        s.timeStand = null;
    }

    /** Меняет текст только если он изменился; если стойки кто-то убрал — создаёт заново. */
    private void updateHologram(MysticSession s, long now) {
        String status;
        String time;
        if (s.state == MysticSession.State.WAITING) {
            status = cfg.holoActivationText;
            time = cfg.holoWaitingText.replace("%time%", TimeFormat.words(s.openAtMs - now));
        } else {
            status = cfg.holoOpenText;
            long left = disappearAtMs(s) - now;
            time = left == Long.MAX_VALUE - now ? ""
                    : cfg.holoClosingText.replace("%time%", TimeFormat.words(left));
        }
        if (s.timeStand == null || !s.timeStand.isValid() || s.titleStand == null || !s.titleStand.isValid()
                || s.statusStand == null || !s.statusStand.isValid()) {
            World w = Bukkit.getWorld(s.worldId);
            if (w == null) {
                return;
            }
            spawnHolograms(s, w);
        }
        if (!status.equals(s.lastStatusText)) {
            setLine(s.statusStand, status);
            s.lastStatusText = status;
        }
        if (!time.equals(s.lastTimeText)) {
            setLine(s.timeStand, time);
            s.lastTimeText = time;
        }
    }

    private static void setLine(ArmorStand stand, String miniMessage) {
        stand.customName(miniMessage.isEmpty() ? Component.empty()
                : net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(miniMessage));
        stand.setCustomNameVisible(!miniMessage.isEmpty());
    }

    // ───────────────────────── взаимодействие игроков ─────────────────────────

    MysticSession sessionAt(Block b) {
        UUID w = b.getWorld().getUID();
        for (MysticSession s : sessions) {
            if (s.x == b.getX() && s.y == b.getY() && s.z == b.getZ() && s.worldId.equals(w)) {
                return s;
            }
        }
        return null;
    }

    boolean isProtected(Block b) {
        if (sessions.isEmpty()) {
            return false;
        }
        UUID w = b.getWorld().getUID();
        int x = b.getX();
        int z = b.getZ();
        for (MysticSession s : sessions) {
            if (s.zone.contains(x, z) && s.worldId.equals(w)) {
                return true;
            }
        }
        return false;
    }

    void onChestInteract(Player p, MysticSession s) {
        if (!p.hasPermission("events.use")) {
            return;
        }
        if (s.state == MysticSession.State.WAITING) {
            p.sendActionBar(plugin.messages().get("mystic-closed",
                    Messages.text("time", TimeFormat.format(s.openAtMs - ms()))));
            return;
        }
        if (s.book == null || s.inventory == null) {
            return;
        }
        if (s.lootStartedAtMs == 0) {
            startLoot(s);
        }
        p.openInventory(s.inventory);
    }

    /**
     * Забор награды. Порядок важен: кулдаун → награда видна и свободна → хватает места → атомарное
     * закрепление за игроком → выдача → (только при успехе) окончательное удаление из общего GUI.
     * Всё на главном потоке + атомарный LootBook, поэтому два игрока не могут получить один предмет.
     */
    void handleLootClick(Player p, MysticSession s, int slot) {
        if (!running || !sessions.contains(s) || s.state != MysticSession.State.OPEN || s.book == null) {
            return;
        }
        long nowNanos = System.nanoTime();
        if (!cooldown.ready(p.getUniqueId(), nowNanos, cfg.claimCooldownMs)) {
            return;
        }
        ItemStack proto = s.book.itemAt(slot);
        if (proto == null) {
            return;   // пустой, ещё не показанный, уже занятый или забранный слот
        }
        ItemStack give = proto.clone();
        if (!InventoryUtil.fits(p.getInventory(), give)) {
            p.sendActionBar(plugin.messages().get("inventory-full"));
            return;
        }
        if (!s.book.reserve(slot)) {
            return;
        }
        if (!InventoryUtil.give(p, give)) {
            s.book.release(slot);
            p.sendActionBar(plugin.messages().get("inventory-full"));
            return;
        }
        s.book.commit(slot);
        s.inventory.setItem(slot, null);   // исчезает сразу у всех, кто смотрит это GUI
        cooldown.mark(p.getUniqueId(), nowNanos);
        if (s.completedAtMs == 0 && s.book.isComplete()) {
            s.completedAtMs = ms();
        }
        persist();
    }

    void forget(UUID id) {
        cooldown.forget(id);
    }

    // ───────────────────────── предмет «Mystic» для /event give ─────────────────────────

    ItemStack createMysticItem(Rarity r, int amount) {
        ItemStack item = new ItemStack(Material.ENDER_CHEST, amount);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(r.component());
        meta.getPersistentDataContainer().set(itemKey, PersistentDataType.STRING, r.id());
        item.setItemMeta(meta);
        return item;
    }

    static final String RANDOM_KIND = "random";

    /** «Случайный Mystic»: редкость определяется в момент установки по random-weights. */
    ItemStack createRandomItem(int amount) {
        ItemStack item = new ItemStack(Material.ENDER_CHEST, amount);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(randomItemName());
        meta.getPersistentDataContainer().set(itemKey, PersistentDataType.STRING, RANDOM_KIND);
        item.setItemMeta(meta);
        return item;
    }

    static Component randomItemName() {
        return Component.text("Случайный Mystic", NamedTextColor.AQUA).decoration(TextDecoration.ITALIC, false);
    }

    boolean isRandomItem(ItemStack item) {
        if (item == null || !item.hasItemMeta()) {
            return false;
        }
        return RANDOM_KIND.equals(item.getItemMeta().getPersistentDataContainer().get(itemKey, PersistentDataType.STRING));
    }

    /** Бросок редкости: только среди редкостей, в хранилище которых есть награды; null, если наград нет нигде. */
    private Rarity rollRandom() {
        Map<Rarity, Integer> eff = new EnumMap<>(Rarity.class);
        for (Rarity r : Rarity.values()) {
            eff.put(r, store.count(r) > 0 ? cfg.randomWeights.getOrDefault(r, 0) : 0);
        }
        return WeightedPicker.pick(eff, ThreadLocalRandom.current());
    }

    boolean createGivenRandom(Player p, Block placed) {
        Rarity r = rollRandom();
        if (r == null) {
            plugin.messages().send(p, "random-pool-empty");
            return false;
        }
        return createGiven(p, placed, r);
    }

    Rarity rarityOfItem(ItemStack item) {
        if (item == null || !item.hasItemMeta()) {
            return null;
        }
        return Rarity.parse(item.getItemMeta().getPersistentDataContainer().get(itemKey, PersistentDataType.STRING));
    }

    // ───────────────────────── команды ─────────────────────────

    void openEditor(Player p, Rarity r) {
        UUID cur = editors.get(r);
        if (cur != null && !cur.equals(p.getUniqueId())) {
            Player other = Bukkit.getPlayer(cur);
            if (other != null && other.getOpenInventory().getTopInventory().getHolder(false) instanceof AdminRewardMenu) {
                plugin.messages().send(p, "rewards-busy");
                return;
            }
        }
        editors.put(r, p.getUniqueId());
        p.openInventory(new AdminRewardMenu(this, r, p).getInventory());
    }

    void releaseEditor(Rarity r, UUID id) {
        editors.remove(r, id);
    }

    void saveRewards(Rarity r, ItemStack[] contents) {
        store.save(r, contents);
    }

    /** /event start: открывает ожидающий Mystic сейчас, а если его нет — создаёт и сразу открывает. */
    boolean startNow() {
        if (!running || resolveWorld() == null || pickRarity() == null) {
            return false;
        }
        autoSpawn = true;
        for (MysticSession s : sessions) {
            if (!s.fromGive && s.state == MysticSession.State.WAITING) {
                s.openAtMs = ms();
                openSession(s);
                persist();
                return true;
            }
        }
        if (sessions.stream().noneMatch(x -> !x.fromGive)) {
            retryAtMs = 0;
            spawnCycle(true);
        }
        persist();
        return true;
    }

    /** /event stop: убирает все активные Mystic и ставит автозапуск на паузу до /event start. */
    void stopActive() {
        autoSpawn = false;
        immediateNext = false;
        for (MysticSession s : new ArrayList<>(sessions)) {
            despawn(s, false);
        }
        persist();
    }
}
