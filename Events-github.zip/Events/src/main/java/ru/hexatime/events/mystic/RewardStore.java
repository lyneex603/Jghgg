package ru.hexatime.events.mystic;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;
import ru.hexatime.events.EventsPlugin;
import ru.hexatime.events.core.util.FileUtil;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.EnumMap;
import java.util.List;
import java.util.logging.Level;

/** Хранилища наград: по одному файлу plugins/Events/rewards/<редкость>.yml на каждую редкость, независимо друг от друга. */
final class RewardStore {

    static final int SIZE = 54;

    private final EventsPlugin plugin;
    private final File dir;
    private final EnumMap<Rarity, ItemStack[]> pools = new EnumMap<>(Rarity.class);

    RewardStore(EventsPlugin plugin) {
        this.plugin = plugin;
        this.dir = new File(plugin.getDataFolder(), "rewards");
    }

    void loadAll() {
        dir.mkdirs();
        for (Rarity r : Rarity.values()) {
            pools.put(r, load(r));
        }
    }

    private File file(Rarity r) {
        return new File(dir, r.id() + ".yml");
    }

    private ItemStack[] load(Rarity r) {
        ItemStack[] arr = new ItemStack[SIZE];
        File f = file(r);
        if (!f.exists()) {
            return arr;
        }
        ConfigurationSection s = YamlConfiguration.loadConfiguration(f).getConfigurationSection("slots");
        if (s == null) {
            return arr;
        }
        for (String key : s.getKeys(false)) {
            try {
                int slot = Integer.parseInt(key);
                if (slot < 0 || slot >= SIZE) {
                    continue;
                }
                ItemStack it = ItemStack.deserializeBytes(Base64.getDecoder().decode(s.getString(key, "")));
                if (!it.getType().isAir()) {
                    arr[slot] = it;
                }
            } catch (Exception ex) {
                plugin.getLogger().log(Level.WARNING, "Пропущен повреждённый предмет " + r.id() + " слот " + key, ex);
            }
        }
        ItemUniq.removeDuplicates(arr);
        return arr;
    }

    /** Копия содержимого хранилища (54 слота) для меню администратора. */
    ItemStack[] slots(Rarity r) {
        ItemStack[] src = pools.getOrDefault(r, new ItemStack[SIZE]);
        ItemStack[] copy = new ItemStack[SIZE];
        for (int i = 0; i < SIZE; i++) {
            copy[i] = src[i] == null ? null : src[i].clone();
        }
        return copy;
    }

    /** Уникальные предметы пула (копии). */
    List<ItemStack> items(Rarity r) {
        List<ItemStack> out = new ArrayList<>();
        for (ItemStack it : slots(r)) {
            if (it != null) {
                out.add(it);
            }
        }
        return out;
    }

    int count(Rarity r) {
        int n = 0;
        for (ItemStack it : pools.getOrDefault(r, new ItemStack[SIZE])) {
            if (it != null) {
                n++;
            }
        }
        return n;
    }

    /** Сохраняет содержимое (после проверки на дубликаты) в память и на диск. */
    void save(Rarity r, ItemStack[] contents) {
        ItemStack[] copy = new ItemStack[SIZE];
        for (int i = 0; i < SIZE && i < contents.length; i++) {
            copy[i] = contents[i] == null || contents[i].getType().isAir() ? null : contents[i].clone();
        }
        ItemUniq.removeDuplicates(copy);
        pools.put(r, copy);

        YamlConfiguration y = new YamlConfiguration();
        for (int i = 0; i < SIZE; i++) {
            if (copy[i] != null) {
                y.set("slots." + i, Base64.getEncoder().encodeToString(copy[i].serializeAsBytes()));
            }
        }
        String data = y.saveToString();
        File target = file(r);
        plugin.io(() -> {
            try {
                FileUtil.writeAtomic(target, data);
            } catch (IOException e) {
                plugin.getLogger().log(Level.SEVERE, "Не удалось сохранить награды " + r.id(), e);
            }
        });
    }
}
