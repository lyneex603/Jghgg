package ru.hexatime.events.mystic.logic;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Кулдаун между успешными заборами предметов одним игроком. Время передаётся снаружи (System.nanoTime). */
public final class ClaimCooldown {

    private final Map<UUID, Long> last = new HashMap<>();

    public boolean ready(UUID id, long nowNanos, long cooldownMs) {
        Long l = last.get(id);
        return l == null || nowNanos - l >= cooldownMs * 1_000_000L;
    }

    public void mark(UUID id, long nowNanos) {
        last.put(id, nowNanos);
    }

    public void forget(UUID id) {
        last.remove(id);
    }
}
