package ru.hexatime.events.mystic.logic;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/** Генерация раскладки наград одного Mystic: какие предметы, в каких слотах и когда появляются. Без Bukkit. */
public final class LootLayout {

    private LootLayout() {
    }

    /** slot — слот GUI; revealOffsetMs — через сколько мс после начала лута предмет появится (0 = сразу). */
    public record Entry<T>(int slot, T item, long revealOffsetMs) {
    }

    /**
     * Берёт случайные уникальные предметы из пула (без повторов), раскладывает по случайным
     * непересекающимся слотам. Первые initial предметов видны сразу, остальные появляются
     * по одному: firstDelayMs, firstDelayMs + stepMs, ...
     */
    public static <T> List<Entry<T>> generate(List<T> pool, int guiSize, int initialMin, int initialMax,
                                              int additional, long firstDelayMs, long stepMs, Random rnd) {
        return build(pool, guiSize, initialMin, initialMax, additional, k -> firstDelayMs + stepMs * k, rnd);
    }

    /**
     * То же, но задержки между появлениями дополнительных предметов повторяются по кругу:
     * для [700, 1100] появление через 0,7 с, затем +1,1 с, затем +0,7 с, затем +1,1 с и т.д.
     */
    public static <T> List<Entry<T>> generateCyclic(List<T> pool, int guiSize, int initialMin, int initialMax,
                                                    int additional, long[] gapsMs, Random rnd) {
        long[] gaps = (gapsMs == null || gapsMs.length == 0) ? new long[]{700L, 1100L} : gapsMs;
        long[] cumulative = new long[Math.max(0, additional) + 1];
        long t = 0;
        for (int k = 0; k < cumulative.length; k++) {
            t += gaps[k % gaps.length];
            cumulative[k] = t;
        }
        return build(pool, guiSize, initialMin, initialMax, additional, k -> cumulative[k], rnd);
    }

    private static <T> List<Entry<T>> build(List<T> pool, int guiSize, int initialMin, int initialMax,
                                            int additional, java.util.function.IntToLongFunction offsetOf, Random rnd) {
        int p = pool.size();
        if (p == 0 || guiSize <= 0) {
            return List.of();
        }
        int lo = Math.max(1, Math.min(initialMin, initialMax));
        int hi = Math.max(lo, Math.max(initialMin, initialMax));
        int initial = Math.min(lo + rnd.nextInt(hi - lo + 1), p);
        int total = Math.min(Math.min(initial + Math.max(0, additional), p), guiSize);
        initial = Math.min(initial, total);

        List<T> items = new ArrayList<>(pool);
        Collections.shuffle(items, rnd);
        List<Integer> slots = new ArrayList<>(guiSize);
        for (int i = 0; i < guiSize; i++) {
            slots.add(i);
        }
        Collections.shuffle(slots, rnd);

        List<Entry<T>> out = new ArrayList<>(total);
        for (int i = 0; i < total; i++) {
            long offset = i < initial ? 0L : offsetOf.applyAsLong(i - initial);
            out.add(new Entry<>(slots.get(i), items.get(i), offset));
        }
        return out;
    }
}
