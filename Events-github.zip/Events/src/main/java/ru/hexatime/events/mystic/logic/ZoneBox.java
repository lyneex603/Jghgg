package ru.hexatime.events.mystic.logic;

/** Квадратная защитная зона (по X и Z, на всю высоту): radius=6 даёт 13×13. */
public record ZoneBox(int cx, int cz, int radius) {

    public boolean contains(int x, int z) {
        return Math.abs(x - cx) <= radius && Math.abs(z - cz) <= radius;
    }

    public boolean intersects(ZoneBox o, int margin) {
        return Math.abs(cx - o.cx) <= radius + o.radius + margin
                && Math.abs(cz - o.cz) <= radius + o.radius + margin;
    }

    public int size() {
        return radius * 2 + 1;
    }

    public long distanceSq(ZoneBox o) {
        long dx = cx - o.cx;
        long dz = cz - o.cz;
        return dx * dx + dz * dz;
    }
}
