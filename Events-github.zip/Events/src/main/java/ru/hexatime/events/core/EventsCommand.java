package ru.hexatime.events.core;

import net.kyori.adventure.text.Component;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import ru.hexatime.events.EventsPlugin;
import ru.hexatime.events.core.gui.EventsMenu;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.Set;

/**
 * /event. Маршрутизация: help / time / reload — ядро; /event <id события> [команда] — модуль;
 * иначе подкоманда ищется среди модулей (пока событие одно, поэтому /event give, /event start и т.д. работают напрямую).
 */
public final class EventsCommand implements TabExecutor {

    private final EventsPlugin plugin;
    private final EventRegistry registry;

    public EventsCommand(EventsPlugin plugin, EventRegistry registry) {
        this.plugin = plugin;
        this.registry = registry;
    }

    private Messages msg() {
        return plugin.messages();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            if (!(sender instanceof Player p)) {
                help(sender);
                return true;
            }
            if (!p.hasPermission("events.use")) {
                msg().send(p, "no-permission");
                return true;
            }
            p.openInventory(new EventsMenu(plugin, registry.enabled()).getInventory());
            return true;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "help" -> help(sender);
            case "time", "next" -> time(sender);
            case "reload" -> {
                if (!sender.hasPermission("events.admin.reload")) {
                    msg().send(sender, "no-permission");
                } else {
                    plugin.reloadAll();
                    msg().send(sender, "reload-done");
                }
            }
            default -> route(sender, sub, args);
        }
        return true;
    }

    private void route(CommandSender sender, String sub, String[] args) {
        Optional<EventModule> byId = registry.byId(sub);
        if (byId.isPresent()) {
            EventModule m = byId.get();
            if (args.length == 1) {
                openModuleMenu(sender, m);
            } else {
                dispatch(sender, m, args[1].toLowerCase(Locale.ROOT), Arrays.copyOfRange(args, 2, args.length));
            }
            return;
        }
        List<EventModule> candidates = registry.bySubcommand(sub);
        if (candidates.isEmpty()) {
            msg().send(sender, "unknown-command");
        } else if (candidates.size() > 1) {
            msg().send(sender, "ambiguous");
        } else {
            dispatch(sender, candidates.get(0), sub, Arrays.copyOfRange(args, 1, args.length));
        }
    }

    private void openModuleMenu(CommandSender sender, EventModule m) {
        if (!(sender instanceof Player p)) {
            msg().send(sender, "player-only");
            return;
        }
        if (!p.hasPermission("events.use")) {
            msg().send(p, "no-permission");
            return;
        }
        if (!m.isEnabled()) {
            msg().send(p, "module-disabled");
            return;
        }
        m.openMenu(p);
    }

    private void dispatch(CommandSender sender, EventModule m, String sub, String[] rest) {
        if (!m.subcommands().contains(sub)) {
            msg().send(sender, "unknown-command");
            return;
        }
        if (!m.canUse(sender, sub)) {
            msg().send(sender, "no-permission");
            return;
        }
        if (!m.isEnabled()) {
            msg().send(sender, "module-disabled");
            return;
        }
        if (!m.handle(sender, sub, rest)) {
            msg().send(sender, "unknown-command");
        }
    }

    private void help(CommandSender s) {
        msg().send(s, "help-header");
        line(s, "/event", "открыть меню событий");
        line(s, "/event help", "список команд");
        line(s, "/event next", "какое событие следующее и через сколько");
        line(s, "/event mystic", "открыть меню Mystic");
        if (s.hasPermission("events.admin.give")) {
            line(s, "/event give <игрок> <редкость|random> [кол-во]", "выдать Mystic");
        }
        if (s.hasPermission("events.admin.start")) {
            line(s, "/event start", "запустить Mystic сейчас");
        }
        if (s.hasPermission("events.admin.stop")) {
            line(s, "/event stop", "остановить активные Mystic");
        }
        if (s.hasPermission("events.admin.rewards")) {
            line(s, "/event rewards <редкость>", "настроить награды");
        }
        if (s.hasPermission("events.admin.reload")) {
            line(s, "/event reload", "перезагрузить конфигурацию");
        }
    }

    private void line(CommandSender s, String cmd, String desc) {
        msg().send(s, "help-line", Messages.text("cmd", cmd), Messages.text("desc", desc));
    }

    private void time(CommandSender sender) {
        if (!sender.hasPermission("events.use")) {
            msg().send(sender, "no-permission");
            return;
        }
        List<Component> lines = new ArrayList<>();
        for (EventModule m : registry.enabled()) {
            Component status = m.timeStatus();
            if (status != null) {
                lines.add(msg().get("time-line", Messages.comp("event", m.displayName()), Messages.comp("status", status)));
            }
        }
        if (lines.isEmpty()) {
            msg().send(sender, "time-none");
            return;
        }
        msg().send(sender, "time-header");
        lines.forEach(sender::sendMessage);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            Set<String> out = new LinkedHashSet<>(List.of("help", "time", "next"));
            if (sender.hasPermission("events.admin.reload")) {
                out.add("reload");
            }
            for (EventModule m : registry.enabled()) {
                out.add(m.id());
                for (String s : m.subcommands()) {
                    if (m.canUse(sender, s)) {
                        out.add(s);
                    }
                }
            }
            return filter(out, args[0]);
        }
        String first = args[0].toLowerCase(Locale.ROOT);
        Optional<EventModule> byId = registry.byId(first);
        if (byId.isPresent()) {
            EventModule m = byId.get();
            if (args.length == 2) {
                List<String> subs = new ArrayList<>();
                for (String s : m.subcommands()) {
                    if (m.canUse(sender, s)) {
                        subs.add(s);
                    }
                }
                return filter(subs, args[1]);
            }
            String sub = args[1].toLowerCase(Locale.ROOT);
            return m.canUse(sender, sub) ? m.complete(sender, sub, Arrays.copyOfRange(args, 2, args.length)) : List.of();
        }
        List<EventModule> c = registry.bySubcommand(first);
        if (c.size() == 1 && c.get(0).canUse(sender, first)) {
            return c.get(0).complete(sender, first, Arrays.copyOfRange(args, 1, args.length));
        }
        return List.of();
    }

    private static List<String> filter(java.util.Collection<String> options, String prefix) {
        String p = prefix.toLowerCase(Locale.ROOT);
        List<String> out = new ArrayList<>();
        for (String o : options) {
            if (o.toLowerCase(Locale.ROOT).startsWith(p)) {
                out.add(o);
            }
        }
        return out;
    }
}
