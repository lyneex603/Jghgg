package ru.hexatime.events.mystic;

import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.Directional;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockBurnEvent;
import org.bukkit.event.block.BlockDispenseEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockFadeEvent;
import org.bukkit.event.block.BlockFertilizeEvent;
import org.bukkit.event.block.BlockFormEvent;
import org.bukkit.event.block.BlockFromToEvent;
import org.bukkit.event.block.BlockIgniteEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.block.LeavesDecayEvent;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.hanging.HangingBreakByEntityEvent;
import org.bukkit.event.hanging.HangingPlaceEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.event.world.StructureGrowEvent;

/**
 * Защитная зона 13×13 (радиус из конфига) на всю высоту. Обычные игроки не могут менять блоки;
 * мир (жидкости, огонь, взрывы, поршни, мобы, рост структур) тоже не может. Обход: events.bypass.
 */
final class ProtectionListener implements Listener {

    static final String BYPASS = "events.bypass";

    private final MysticModule module;

    ProtectionListener(MysticModule module) {
        this.module = module;
    }

    private boolean prot(Block b) {
        return module.isProtected(b);
    }

    private static boolean bypass(Player p) {
        return p != null && p.hasPermission(BYPASS);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        if (prot(e.getBlock()) && !bypass(e.getPlayer())) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {   // включает BlockMultiPlaceEvent
        if ((prot(e.getBlockPlaced()) || prot(e.getBlockAgainst())) && !bypass(e.getPlayer())) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBucketEmpty(PlayerBucketEmptyEvent e) {
        if ((prot(e.getBlock()) || prot(e.getBlockClicked())) && !bypass(e.getPlayer())) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBucketFill(PlayerBucketFillEvent e) {
        if (prot(e.getBlockClicked()) && !bypass(e.getPlayer())) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onFlow(BlockFromToEvent e) {
        if (prot(e.getToBlock())) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onIgnite(BlockIgniteEvent e) {
        if (prot(e.getBlock()) && !bypass(e.getPlayer())) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBurn(BlockBurnEvent e) {
        if (prot(e.getBlock())) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onForm(BlockFormEvent e) {   // лёд, снег, распространение травы/мицелия (BlockSpreadEvent), голем
        if (prot(e.getBlock())) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onFade(BlockFadeEvent e) {
        if (prot(e.getBlock())) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onLeaves(LeavesDecayEvent e) {
        if (prot(e.getBlock())) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onStructureGrow(StructureGrowEvent e) {
        if (!bypass(e.getPlayer()) && e.getBlocks().stream().anyMatch(s -> prot(s.getBlock()))) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onFertilize(BlockFertilizeEvent e) {
        if (!bypass(e.getPlayer()) && (prot(e.getBlock()) || e.getBlocks().stream().anyMatch(s -> prot(s.getBlock())))) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPistonExtend(BlockPistonExtendEvent e) {
        BlockFace dir = e.getDirection();
        if (prot(e.getBlock().getRelative(dir))) {
            e.setCancelled(true);
            return;
        }
        for (Block b : e.getBlocks()) {
            if (prot(b) || prot(b.getRelative(dir))) {
                e.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPistonRetract(BlockPistonRetractEvent e) {
        BlockFace dir = e.getDirection();
        for (Block b : e.getBlocks()) {
            if (prot(b) || prot(b.getRelative(dir))) {
                e.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityExplode(EntityExplodeEvent e) {
        e.blockList().removeIf(this::prot);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockExplode(BlockExplodeEvent e) {
        e.blockList().removeIf(this::prot);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityChange(EntityChangeBlockEvent e) {   // эндермен, падающие блоки, топтание грядок, иссушитель
        Entity en = e.getEntity();
        if (prot(e.getBlock()) && !(en instanceof Player p && bypass(p))) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDispense(BlockDispenseEvent e) {
        Block disp = e.getBlock();
        if (!(disp.getBlockData() instanceof Directional d)) {
            return;
        }
        Block target = disp.getRelative(d.getFacing());
        if (!prot(target)) {
            return;
        }
        Material m = e.getItem().getType();
        if (m.name().endsWith("_BUCKET") || m == Material.FLINT_AND_STEEL || m == Material.FIRE_CHARGE
                || m == Material.BONE_MEAL || m == Material.TNT || m == Material.SHEARS) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHangingPlace(HangingPlaceEvent e) {
        if (prot(e.getBlock()) && !bypass(e.getPlayer())) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHangingBreak(HangingBreakByEntityEvent e) {
        if (prot(e.getEntity().getLocation().getBlock()) && !(e.getRemover() instanceof Player p && bypass(p))) {
            e.setCancelled(true);
        }
    }
}
