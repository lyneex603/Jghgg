package ru.hexatime.events.core;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;

/** Сообщения из config.yml (раздел messages, формат MiniMessage). Читаются при каждом обращении, reload не нужен. */
public final class Messages {

    private static final MiniMessage MM = MiniMessage.miniMessage();
    private final JavaPlugin plugin;

    public Messages(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public Component get(String key, TagResolver... resolvers) {
        String raw = plugin.getConfig().getString("messages." + key);
        if (raw == null) {
            raw = "<red>[нет сообщения: " + key + "]";
        }
        return MM.deserialize(raw, resolvers);
    }

    public void send(CommandSender to, String key, TagResolver... resolvers) {
        to.sendMessage(get(key, resolvers));
    }

    public static TagResolver text(String name, String value) {
        return Placeholder.unparsed(name, value);
    }

    public static TagResolver comp(String name, Component value) {
        return Placeholder.component(name, value);
    }
}
