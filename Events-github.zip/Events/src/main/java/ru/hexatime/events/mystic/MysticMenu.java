package ru.hexatime.events.mystic;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import ru.hexatime.events.core.gui.MenuHolder;

import java.util.HashMap;
import java.util.Map;

/** Меню Mystic: четыре редкости, у каждой свой GUI. */
final class MysticMenu extends MenuHolder {

    private static final int[] SLOTS = {10, 12, 14, 16};

    private final MysticModule module;
    private final Map<Integer, Rarity> bySlot = new HashMap<>();

    MysticMenu(MysticModule module) {
        this.module = module;
        Inventory inv = createInventory(27, Component.text("Mystic"));
        Rarity[] all = Rarity.values();
        for (int i = 0; i < all.length; i++) {
            ItemStack it = new ItemStack(Material.ENDER_CHEST);
            ItemMeta meta = it.getItemMeta();
            meta.displayName(all[i].component());
            it.setItemMeta(meta);
            inv.setItem(SLOTS[i], it);
            bySlot.put(SLOTS[i], all[i]);
        }
    }

    @Override
    public void onClick(InventoryClickEvent e) {
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p) || !getInventory().equals(e.getClickedInventory())) {
            return;
        }
        Rarity r = bySlot.get(e.getSlot());
        if (r != null) {
            Bukkit.getScheduler().runTask(module.plugin(), () -> p.openInventory(new RarityViewMenu(module, r).getInventory()));
        }
    }
}
