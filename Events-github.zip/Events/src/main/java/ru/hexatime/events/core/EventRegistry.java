package ru.hexatime.events.core;

import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.logging.Level;

public final class EventRegistry {

    private final JavaPlugin plugin;
    private final Map<String, EventModule> modules = new LinkedHashMap<>();

    public EventRegistry(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public void register(EventModule module) {
        String id = module.id().toLowerCase(Locale.ROOT);
        if (modules.putIfAbsent(id, module) != null) {
            throw new IllegalStateException("Событие с id '" + id + "' уже зарегистрировано");
        }
    }

    public void enableAll() {
        for (EventModule m : modules.values()) {
            try {
                m.enable();
            } catch (Throwable t) {
                plugin.getLogger().log(Level.SEVERE, "Не удалось запустить событие " + m.id(), t);
            }
        }
    }

    public void disableAll() {
        for (EventModule m : modules.values()) {
            try {
                m.disable();
            } catch (Throwable t) {
                plugin.getLogger().log(Level.SEVERE, "Ошибка при остановке события " + m.id(), t);
            }
        }
    }

    public void reloadAll() {
        for (EventModule m : modules.values()) {
            try {
                m.reload();
            } catch (Throwable t) {
                plugin.getLogger().log(Level.SEVERE, "Ошибка перезагрузки события " + m.id(), t);
            }
        }
    }

    public Collection<EventModule> all() {
        return modules.values();
    }

    public List<EventModule> enabled() {
        List<EventModule> out = new ArrayList<>();
        for (EventModule m : modules.values()) {
            if (m.isEnabled()) {
                out.add(m);
            }
        }
        return out;
    }

    public Optional<EventModule> byId(String id) {
        return Optional.ofNullable(modules.get(id.toLowerCase(Locale.ROOT)));
    }

    public List<EventModule> bySubcommand(String sub) {
        List<EventModule> out = new ArrayList<>();
        for (EventModule m : modules.values()) {
            if (m.subcommands().contains(sub)) {
                out.add(m);
            }
        }
        return out;
    }
}
