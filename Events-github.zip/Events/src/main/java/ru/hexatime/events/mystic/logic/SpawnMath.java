package ru.hexatime.events.mystic.logic;

import java.util.Random;

public final class SpawnMath {

    private SpawnMath() {
    }

    /** Случайное целое в [min; max] включительно; границы можно передать в любом порядке. */
    public static int between(Random rnd, int min, int max) {
        int lo = Math.min(min, max);
        int hi = Math.max(min, max);
        return lo + rnd.nextInt(hi - lo + 1);
    }
}
