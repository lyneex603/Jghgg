package ru.hexatime.events.mystic;

import org.bukkit.HeightMap;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Tag;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import ru.hexatime.events.mystic.logic.ZoneBox;

import java.util.Collection;
import java.util.OptionalInt;

/** Проверка места появления Mystic. Вызывается на главном потоке, когда нужные чанки уже загружены. */
final class SpawnChecker {

    private SpawnChecker() {
    }

    /** Возвращает Y, куда ставить сундук, или пусто, если место не подходит. */
    static OptionalInt findPlacement(World w, int x, int z, MysticConfig cfg, Collection<ZoneBox> sameWorldZones) {
        int r = cfg.radius;
        ZoneBox zone = new ZoneBox(x, z, r);

        // зона целиком внутри границы мира
        for (int[] c : new int[][]{{x - r, z - r}, {x + r, z - r}, {x - r, z + r}, {x + r, z + r}}) {
            if (!w.getWorldBorder().isInside(new Location(w, c[0] + 0.5, 64, c[1] + 0.5))) {
                return OptionalInt.empty();
            }
        }
        // не пересекается с чужими зонами и не слишком близко к ним
        long minSq = (long) cfg.minDistance * cfg.minDistance;
        for (ZoneBox o : sameWorldZones) {
            if (zone.intersects(o, 0) || zone.distanceSq(o) < minSq) {
                return OptionalInt.empty();
            }
        }

        int minY = Integer.MAX_VALUE;
        int maxY = Integer.MIN_VALUE;
        int centerY = 0;
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                Block top = w.getHighestBlockAt(x + dx, z + dz, HeightMap.MOTION_BLOCKING_NO_LEAVES);
                if (!isGround(top)) {
                    return OptionalInt.empty();   // вода, лава, лёд, листва, ствол дерева
                }
                int y = top.getY();
                minY = Math.min(minY, y);
                maxY = Math.max(maxY, y);
                if (dx == 0 && dz == 0) {
                    centerY = y;
                }
            }
        }
        if (maxY - minY > cfg.maxHeightDiff) {
            return OptionalInt.empty();
        }
        if (centerY + 4 >= w.getMaxHeight() || centerY <= w.getMinHeight() + 2) {
            return OptionalInt.empty();
        }
        Block ground = w.getBlockAt(x, centerY, z);
        Block c1 = ground.getRelative(BlockFace.UP);
        Block c2 = c1.getRelative(BlockFace.UP);
        if (!isFree(c1) || !isFree(c2)) {
            return OptionalInt.empty();
        }
        return OptionalInt.of(centerY + 1);
    }

    private static boolean isFree(Block b) {
        return b.isEmpty() || (b.isPassable() && !b.isLiquid());
    }

    private static boolean isGround(Block b) {
        Material m = b.getType();
        if (b.isLiquid() || !m.isSolid()) {
            return false;
        }
        if (Tag.LEAVES.isTagged(m) || Tag.LOGS.isTagged(m)) {
            return false;
        }
        return m != Material.ICE && m != Material.PACKED_ICE && m != Material.BLUE_ICE && m != Material.FROSTED_ICE;
    }
}
