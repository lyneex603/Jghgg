package ru.hexatime.events.mystic;

import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import ru.hexatime.events.core.gui.MenuHolder;

/**
 * Общий GUI лута одного Mystic. Инвентарь ОДИН на всех игроков: убрали предмет — он сразу исчез у всех.
 * Любой клик по верхнему инвентарю отменяется, предмет выдаёт только module.handleLootClick.
 */
final class MysticLootHolder extends MenuHolder {

    private final MysticModule module;
    private final MysticSession session;

    MysticLootHolder(MysticModule module, MysticSession session) {
        this.module = module;
        this.session = session;
        createInventory(MysticModule.GUI_SIZE, session.rarity.component());
    }

    @Override
    public void onClick(InventoryClickEvent e) {
        Inventory top = e.getInventory();
        if (top.equals(e.getClickedInventory())) {
            e.setCancelled(true);
            if (e.getWhoClicked() instanceof Player p) {
                module.handleLootClick(p, session, e.getSlot());
            }
            return;
        }
        // клики в своём инвентаре разрешены, но нельзя перекладывать/собирать предметы в верхнее меню
        InventoryAction a = e.getAction();
        if (a == InventoryAction.MOVE_TO_OTHER_INVENTORY || a == InventoryAction.COLLECT_TO_CURSOR
                || a == InventoryAction.UNKNOWN) {
            e.setCancelled(true);
        }
    }

    @Override
    public void onDrag(InventoryDragEvent e) {
        int size = e.getInventory().getSize();
        if (e.getRawSlots().stream().anyMatch(s -> s < size)) {
            e.setCancelled(true);
        }
    }
}
